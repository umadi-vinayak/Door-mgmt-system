﻿
using DMSystem.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
            InitializeComponent();
            LoadGrid();
        }
        /// <summary>
        /// Load grid
        /// </summary>
        private void LoadGrid()
        {
            HelloServiceClient serviceReference1 = new HelloServiceClient();
            var rcds = serviceReference1.GetMessage();
            dgEmp.ItemsSource = rcds;
        }
        /// <summary>
        /// Update Ctrls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgEmp_SelectedCellsChanged_1(object sender, SelectedCellsChangedEventArgs e)
        {
                    
            var Drv = (DoorRecord)dgEmp.SelectedItem;
            if(Drv==null)
            {
                return;
            }
            isLocked.IsChecked = Drv.IsLocked;
            isDoorOpened.IsChecked = Drv.IsOpen;
            txtCode.Text = Drv.Label;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(((bool)(isLocked.IsChecked)) ==false&& ((bool)(isDoorOpened.IsChecked)) == false)
            {
                MessageBox.Show("Please select door locked");
            }
            DoorRecord doorRecord = new DoorRecord();
            doorRecord.Label = txtCode.Text;
            doorRecord.IsLocked = ((bool)(isLocked.IsChecked));
            doorRecord.IsOpen = ((bool)(isDoorOpened.IsChecked));
            HelloServiceClient serviceReference1 = new HelloServiceClient();
            serviceReference1.InsertRecord(doorRecord);
            
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            DoorRecord doorRecord = new DoorRecord();
            doorRecord.Label = txtCode.Text;
            doorRecord.IsLocked = ((bool)(isLocked.IsChecked));
            doorRecord.IsOpen = ((bool)(isDoorOpened.IsChecked));
            HelloServiceClient serviceReference1 = new HelloServiceClient();
           serviceReference1.UpdateRecord(doorRecord);
           

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DoorRecord doorRecord = new DoorRecord();
            doorRecord.Label = txtCode.Text;            
            HelloServiceClient serviceReference1 = new HelloServiceClient();
            serviceReference1.DeleteRecord(doorRecord);
            
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            
            HelloServiceClient serviceReference1 = new HelloServiceClient();
            var rcds = serviceReference1.GetMessage();
            dgEmp.ItemsSource = rcds;
        }

        private void isLocked_Checked(object sender, RoutedEventArgs e)
        {
            isDoorOpened.IsChecked = false;
        }
    }
}
