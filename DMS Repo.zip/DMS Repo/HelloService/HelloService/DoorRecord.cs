﻿using System;

namespace HelloService
{
    
    public class DoorRecord
    {
             
        public string Id { get; set; }

        public string Label { get; set; }

        public bool IsOpen { get; set; }

        public bool IsLocked { get; set; }
        
    }
}
