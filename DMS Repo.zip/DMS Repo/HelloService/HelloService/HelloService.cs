﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "HelloService" in both code and config file together.
    public class HelloService : IHelloService
    {
        string connectionString = @"Data Source= INGBTCPIC5DT058\SQLEXPRESS; Initial Catalog = DoorMgmtSystem; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";

        public List<DoorRecord> GetMessage()
        {

            List<DoorRecord> list = new List<DoorRecord>();

            string str = @"Data Source= INGBTCPIC5DT058\SQLEXPRESS; Initial Catalog = DoorMgmtSystem; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";

            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(str))
            {
                SqlDataAdapter sde = new SqlDataAdapter("Select * from DMS", con);
                sde.Fill(dt);
            }
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DoorRecord objDoorRecord = new DoorRecord();
                objDoorRecord.Label = dt.Rows[i]["Label"].ToString();
                if (dt.Rows[i]["IsLocked"].ToString() == "True")
                {
                    objDoorRecord.IsLocked = true;
                }
                else
                {
                    objDoorRecord.IsLocked = false;
                }
                if (dt.Rows[i]["IsOpened"].ToString() == "True")
                {
                    objDoorRecord.IsOpen = true;
                }
                else
                {
                    objDoorRecord.IsOpen = false;
                }
                list.Add(objDoorRecord);
            }
            return list;
        }

        public void InsertRecord(DoorRecord dr)
        {
            
            string query = "INSERT INTO dbo.DMS ( Label, IsLocked, IsOpened) " +
                    "VALUES ( @Label, @IsLocked, @IsOpened) ";
            DataTable dt = new DataTable();

            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, cn))
            {
                // define parameters and their values
                cmd.Parameters.Add("@Label", SqlDbType.NVarChar, 50).Value = dr.Label;
                cmd.Parameters.Add("@IsLocked", SqlDbType.Bit, 1).Value = dr.IsLocked;
                cmd.Parameters.Add("@IsOpened", SqlDbType.Bit, 1).Value = dr.IsOpen;

                // open connection, execute INSERT, close connection
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }

        }

        public void UpdateRecord(DoorRecord dr)
        {
            List<DoorRecord> list = new List<DoorRecord>();
            string query = "UPDATE dbo.DMS SET Label = @Label,@IsLocked=@IsLocked,@IsOpened=@IsOpened WHERE Label=@Label";
            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, cn))
            {
                // define parameters and their values

                cmd.Parameters.Add("@Label", SqlDbType.NVarChar, 50).Value = dr.Label;
                cmd.Parameters.Add("@IsLocked", SqlDbType.Bit, 1).Value = dr.IsLocked;
                cmd.Parameters.Add("@IsOpened", SqlDbType.Bit, 1).Value = dr.IsOpen;
                // open connection, execute INSERT, close connection
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        }
        public void DeleteRecord(DoorRecord dr)
        {
            List<DoorRecord> list = new List<DoorRecord>();

             string query = "DELETE From dbo.DMS WHERE Label=@Label";
            DataTable dt = new DataTable();

            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, cn))
            {
                // define parameters and their values
                cmd.Parameters.Add("@Label", SqlDbType.NVarChar, 50).Value = dr.Label;
                
                // open connection, execute INSERT, close connection
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        }
    }
}

